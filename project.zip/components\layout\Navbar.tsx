"use client";

import Link from "next/link";
import { GraduationCap } from "lucide-react";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">

        <Link
          href="/"
          className="flex items-center gap-3 text-xl font-bold"
        >
          <GraduationCap className="text-blue-600" size={34} />
          <span>Mustey Digital Academy</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">

          <Link href="/">Home</Link>

          <Link href="/courses">Courses</Link>

          <Link href="/about">About</Link>

          <Link href="/contact">Contact</Link>

        </nav>

        <div className="flex gap-3">

          <Link
            href="/login"
            className="px-5 py-2 rounded-lg border"
          >
            Login
          </Link>

          <Link
            href="/register"
            className="px-5 py-2 rounded-lg bg-blue-600 text-white"
          >
            Register
          </Link>

        </div>

      </div>
    </header>
  );
}