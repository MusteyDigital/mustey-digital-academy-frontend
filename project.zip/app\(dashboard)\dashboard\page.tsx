export default function DashboardPage() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold">
        Student Dashboard
      </h1>
    </div>
  );
}