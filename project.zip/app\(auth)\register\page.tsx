export default function RegisterPage() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <h1 className="text-3xl font-bold">
        Register Page
      </h1>
    </div>
  );
}