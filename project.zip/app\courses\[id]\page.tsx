import { courses } from "@/data/courseData";
import { notFound } from "next/navigation";

import CourseHero from "@/features/course/CourseHero";
import CourseSidebar from "@/features/course/CourseSidebar";
import LearningObjectives from "@/features/course/LearningObjectives";
import CurriculumAccordion from "@/features/course/CurriculumAccordion";
import InstructorCard from "@/features/course/InstructorCard";
import Reviews from "@/features/course/Reviews";
import RelatedCourses from "@/features/course/RelatedCourses";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

export default async function CourseDetailsPage({
  params,
}: Props) {
  const { id } = await params;

  const course = courses.find(
    (course) => course.id === Number(id)
  );

  if (!course) {
    notFound();
  }

  return (
    <main className="max-w-7xl mx-auto px-6 py-10">
      <div className="grid lg:grid-cols-3 gap-10">

        <div className="lg:col-span-2">

          <CourseHero
            title={course.title}
            description={course.description}
            category={course.category}
            image={course.image}
            rating={course.rating}
            lessons={course.lessons}
            duration={course.duration}
          />

          <LearningObjectives
            objectives={course.objectives}
          />

          <CurriculumAccordion
            curriculum={course.curriculum}
          />

          <InstructorCard
            instructor={course.instructor}
          />

          <Reviews />

          <RelatedCourses
            currentCourseId={course.id}
            courses={courses}
          />

        </div>

        <CourseSidebar
          image={course.image}
          title={course.title}
          price={course.price}
        />

      </div>
    </main>
  );
}