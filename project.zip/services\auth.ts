import api from "./api";

export async function login(email: string, password: string) {
  const { data } = await api.post("/login", {
    email,
    password,
  });

  return data;
}

export async function register(payload: any) {
  const { data } = await api.post("/register", payload);

  return data;
}

export async function logout() {
  const { data } = await api.post("/logout");

  return data;
}

export async function me() {
  const { data } = await api.get("/user");

  return data;
}