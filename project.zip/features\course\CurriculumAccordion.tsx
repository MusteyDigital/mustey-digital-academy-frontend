"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

import { Card } from "@/components/ui/card";
import { BookOpen } from "lucide-react";
import { CurriculumItem } from "@/types/course";

interface Props {
  curriculum: CurriculumItem[];
}

export default function CurriculumAccordion({
  curriculum,
}: Props) {
  return (
    <section className="mt-16">

      <h2 className="text-3xl font-bold mb-6">
        Course Curriculum
      </h2>

      <Card className="p-6">

        <Accordion
          type="single"
          collapsible
          className="w-full"
        >

          {curriculum.map((module, index) => (

            <AccordionItem
              key={index}
              value={`module-${index}`}
            >

              <AccordionTrigger className="text-lg font-semibold">

                {module.title}

              </AccordionTrigger>

              <AccordionContent>

                <div className="space-y-3">

                  {module.lessons.map((lesson, lessonIndex) => (

                    <div
                      key={lessonIndex}
                      className="flex items-center gap-3 py-2"
                    >

                      <BookOpen
                        size={18}
                        className="text-blue-600"
                      />

                      <span>{lesson}</span>

                    </div>

                  ))}

                </div>

              </AccordionContent>

            </AccordionItem>

          ))}

        </Accordion>

      </Card>

    </section>
  );
}