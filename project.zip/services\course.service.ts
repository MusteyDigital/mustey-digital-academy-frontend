import api from "./api";
import { courses } from "@/data/courseData";

const USE_MOCK_DATA = true;

export async function getCourses() {
  if (USE_MOCK_DATA) {
    return courses;
  }

  const { data } = await api.get("/courses");
  return data;
}

export async function getCourse(id: number) {
  if (USE_MOCK_DATA) {
    return courses.find((course) => course.id === id);
  }

  const { data } = await api.get(`/courses/${id}`);
  return data;
}