import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface Props {
  image: string;
  title: string;
  price: string;
}

export default function CourseSidebar({
  image,
  title,
  price,
}: Props) {
  return (
    <Card className="sticky top-24 overflow-hidden">

      <div className="relative h-56">

        <Image
          src={image}
          alt={title}
          fill
          className="object-cover"
        />

      </div>

      <div className="p-6">

        <h2 className="text-4xl font-bold text-blue-600">
          {price}
        </h2>

        <p className="text-gray-500 mt-2">
          Lifetime Access
        </p>

        <Button className="w-full mt-6">
          Enroll Now
        </Button>

        <Button
          variant="outline"
          className="w-full mt-3"
        >
          Add to Wishlist
        </Button>

      </div>

    </Card>
  );
}